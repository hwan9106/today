package kr.human.di.service;

import kr.human.di.vo.Employee;

public interface EmployeeService {
	 
    void registerEmployee(Employee employee);
}