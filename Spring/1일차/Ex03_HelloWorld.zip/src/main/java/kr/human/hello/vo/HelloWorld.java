package kr.human.hello.vo;

public interface HelloWorld {
	void sayHello(String name);
}
