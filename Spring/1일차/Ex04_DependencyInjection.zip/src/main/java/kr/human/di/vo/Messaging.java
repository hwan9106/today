package kr.human.di.vo;

public interface Messaging {
    public void sendMessage();
}
