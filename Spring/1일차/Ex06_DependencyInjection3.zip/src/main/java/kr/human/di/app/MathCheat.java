package kr.human.di.app;

public class MathCheat {
	
	public void mathCheating() {
		System.out.println("And I Have Stated Math Cheating");
	}
}
